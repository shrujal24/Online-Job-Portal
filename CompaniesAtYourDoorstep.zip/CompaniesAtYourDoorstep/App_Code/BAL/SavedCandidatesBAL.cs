﻿using CompaniesatyourDoorstpe.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

namespace CompaniesatyourDoorstpe.BAL
{
    public class SavedCandidatesBAL : SavedCandidatesBALBase
    {
        #region ComboBox
        #endregion ComboBox
    }
}