﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CompaniesatyourDoorstpe.DAL
{
    public class JobPostDAL : JobPostDALBase
    {
        #region ComboBox
        #endregion ComboBox
    }
}