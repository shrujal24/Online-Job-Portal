﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CompaniesatyourDoorstpe.ENT
{
    public class SavedJobENT : SavedJobENTBase
    {
        
    }
}